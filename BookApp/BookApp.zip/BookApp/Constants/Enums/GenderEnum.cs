﻿namespace BookApp.Constants.Enums
{
    public enum GenderEnum
    {
        m,
        f
    }
}
